package com.example.githubbrowser;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebHistoryItem;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import java.io.ByteArrayInputStream;

public class MainActivity extends Activity {
    private static final String[] BLOCK = {
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google", "google-analytics.com", "googletagmanager.com",
        "scorecardresearch.com", "adnxs.com", "taboola.com", "outbrain.com"
    };
    private WebView web;
    private ProgressBar bar;
    private EditText url;
    private String defaultUA;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        LinearLayout top = new LinearLayout(this);
        Button gear = new Button(this); gear.setText("\u2699");
        Button more = new Button(this); more.setText("\u22ee");
        url = new EditText(this);
        url.setSingleLine(true);
        url.setImeOptions(EditorInfo.IME_ACTION_GO);
        url.setHint("URL oder Suche");
        top.addView(gear);
        top.addView(url, new LinearLayout.LayoutParams(0, -2, 1));
        top.addView(more);
        root.addView(top);

        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        root.addView(bar, new LinearLayout.LayoutParams(-1, 8));
        web = new WebView(this);
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        defaultUA = web.getSettings().getUserAgentString();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                if (!Prefs.b(MainActivity.this, "externalLinks") || isGithub(r.getUrl().getHost())) return false;
                startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl()));
                return true;
            }
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (Prefs.b(MainActivity.this, "adblock")) {
                    String h = r.getUrl().getHost();
                    if (h != null) for (String s : BLOCK)
                        if (h.endsWith(s)) return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
                }
                return null;
            }
            @Override public void onPageStarted(WebView v, String u, Bitmap f) { bar.setVisibility(View.VISIBLE); url.setText(u); }
            @Override public void onPageFinished(WebView v, String u) { bar.setVisibility(View.GONE); }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int p) { bar.setProgress(p); }
            @Override public void onGeolocationPermissionsShowPrompt(String o, android.webkit.GeolocationPermissions.Callback cb) {
                cb.invoke(o, Prefs.b(MainActivity.this, "geo"), false);
            }
        });

        gear.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        url.setOnEditorActionListener((v, a, e) -> { go(url.getText().toString()); return true; });
        more.setOnClickListener(v -> {
            PopupMenu m = new PopupMenu(this, v);
            String[] items = {"Neu laden", "Vorw\u00e4rts", "Startseite", "Teilen", "Im externen Browser \u00f6ffnen",
                "Cache leeren", "Cookies l\u00f6schen", "Verlauf leeren"};
            for (int i = 0; i < items.length; i++) m.getMenu().add(0, i, i, items[i]);
            m.setOnMenuItemClickListener(it -> { menu(it.getItemId()); return true; });
            m.show();
        });

        applyPrefs();
        Uri d = getIntent().getData();
        go(d != null ? d.toString() : Prefs.t(this, "home"));
    }

    private boolean isGithub(String h) {
        return h != null && (h.equals("github.com") || h.endsWith(".github.com")
            || h.endsWith(".githubusercontent.com") || h.endsWith(".githubassets.com"));
    }

    private void go(String in) {
        in = in.trim();
        if (in.isEmpty()) return;
        if (in.startsWith("http://") || in.startsWith("https://")) web.loadUrl(in);
        else if (in.contains(".") && !in.contains(" ")) web.loadUrl("https://" + in);
        else web.loadUrl(Prefs.t(this, "search").replace("%s", Uri.encode(in)));
    }

    private void menu(int id) {
        switch (id) {
            case 0: web.reload(); break;
            case 1: if (web.canGoForward()) web.goForward(); break;
            case 2: go(Prefs.t(this, "home")); break;
            case 3:
                Intent s = new Intent(Intent.ACTION_SEND);
                s.setType("text/plain");
                s.putExtra(Intent.EXTRA_TEXT, web.getUrl());
                startActivity(Intent.createChooser(s, "Teilen"));
                break;
            case 4: startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(web.getUrl()))); break;
            case 5: web.clearCache(true); break;
            case 6:
                CookieManager.getInstance().removeAllCookies(null);
                WebStorage.getInstance().deleteAllData();
                break;
            case 7: web.clearHistory(); break;
        }
    }

    @SuppressWarnings("deprecation")
    private void applyPrefs() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(Prefs.b(this, "js"));
        s.setDomStorageEnabled(Prefs.b(this, "dom"));
        s.setSupportZoom(Prefs.b(this, "zoom"));
        s.setBuiltInZoomControls(Prefs.b(this, "zoom"));
        s.setDisplayZoomControls(false);
        s.setLoadsImagesAutomatically(Prefs.b(this, "images"));
        s.setBlockNetworkImage(!Prefs.b(this, "images"));
        s.setGeolocationEnabled(Prefs.b(this, "geo"));
        s.setMediaPlaybackRequiresUserGesture(Prefs.b(this, "autoplay"));
        s.setMixedContentMode(Prefs.b(this, "mixed") ? WebSettings.MIXED_CONTENT_ALWAYS_ALLOW : WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setAllowFileAccess(Prefs.b(this, "fileaccess"));
        s.setAllowContentAccess(Prefs.b(this, "contentaccess"));
        s.setCacheMode(Prefs.b(this, "cache") ? WebSettings.LOAD_DEFAULT : WebSettings.LOAD_NO_CACHE);
        s.setLoadWithOverviewMode(Prefs.b(this, "overview"));
        s.setUseWideViewPort(Prefs.b(this, "overview"));
        s.setJavaScriptCanOpenWindowsAutomatically(Prefs.b(this, "popups"));
        try { s.setTextZoom(Integer.parseInt(Prefs.t(this, "textzoom").trim())); } catch (Exception e) { s.setTextZoom(100); }

        String ua = Prefs.t(this, "ua").trim();
        if (!ua.isEmpty()) s.setUserAgentString(ua);
        else if (Prefs.b(this, "desktop"))
            s.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36");
        else s.setUserAgentString(defaultUA);
        if (Prefs.b(this, "desktop")) { s.setUseWideViewPort(true); s.setLoadWithOverviewMode(true); }

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(Prefs.b(this, "cookies"));
        cm.setAcceptThirdPartyCookies(web, Prefs.b(this, "thirdcookies"));

        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(Prefs.b(this, "safe"));
        if (Build.VERSION.SDK_INT >= 29)
            s.setForceDark(Prefs.b(this, "dark") ? WebSettings.FORCE_DARK_ON : WebSettings.FORCE_DARK_OFF);
        WebView.setWebContentsDebuggingEnabled(Prefs.b(this, "debug"));

        if (Prefs.b(this, "keepon")) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Prefs.b(this, "fullscreen")) getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    @Override
    protected void onResume() {
        super.onResume();
        applyPrefs();
        web.reload();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
