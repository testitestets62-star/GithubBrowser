package com.example.githubbrowser;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

public class SettingsActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setTitle("Einstellungen");
        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (16 * getResources().getDisplayMetrics().density);
        box.setPadding(p, p, p, p);
        sv.addView(box);
        setContentView(sv);

        for (final String[] s : Prefs.ALL) {
            if (s[0].equals("b")) {
                Switch sw = new Switch(this);
                sw.setText(s[2]);
                sw.setPadding(0, p / 2, 0, p / 2);
                sw.setChecked(Prefs.b(this, s[1]));
                sw.setOnCheckedChangeListener((v, on) ->
                    Prefs.sp(this).edit().putBoolean(s[1], on).apply());
                box.addView(sw);
            } else {
                TextView tv = new TextView(this);
                tv.setText(s[2]);
                tv.setPadding(0, p / 2, 0, 0);
                EditText et = new EditText(this);
                et.setSingleLine(true);
                et.setText(Prefs.t(this, s[1]));
                et.addTextChangedListener(new TextWatcher() {
                    public void beforeTextChanged(CharSequence a, int b, int c, int d) {}
                    public void onTextChanged(CharSequence a, int b, int c, int d) {}
                    public void afterTextChanged(Editable e) {
                        Prefs.sp(SettingsActivity.this).edit().putString(s[1], e.toString()).apply();
                    }
                });
                box.addView(tv);
                box.addView(et);
            }
        }
    }
}
